

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="pq-designer-content-aboutus-section-wrapper">
                <div class="pq-designer-page-2-wrapper content1">
                    <div class="pq-image-section-div">
                        <img src="images/event/4.jpg" alt="Inspire Vision Africa">
                    </div>
                    <div class="pq-designer-info-box">
                        <div class="pq-title-heading">
                            <div class="pq-section-title">
                                <div class="pq-title">
                                    <h5 class="pq-title-heading">EMPOWERING YOUTH TO LEARN, CREATE &amp;
                                        <span class="pq-title-last-word"> LEAD
                                            <svg class="svg" height="100%" width="100%" viewBox="0 0 100 100"
                                                preserveAspectRatio="none">
                                                <path d="M0 0 H 100 V 100 H 0 Z" fill="transparent" stroke="black"
                                                    vector-effect="non-scaling-stroke" stroke-dasharray="400"></path>
                                            </svg>
                                            <span class="pq-svg-dot"></span>
                                        </span>
                                    </h5>
                                </div>
                            </div>
                            <div class="pq-designer-info-box-detail">
                                <p><strong>Inspire Vision Africa</strong> is committed to equipping young Africans with the
                                    knowledge, skills, and digital tools they need to thrive in a fast-changing world. We
                                    believe that every young person carries greatness within — a spark of potential waiting
                                    to be unleashed through learning, creativity, and leadership.</p>

                                <div class="pq-info-box-list">
                                    <ul>
                                        <li>
                                            <span class="pq-info-box-list-icon">
                                                <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle"
                                                    viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                                    </path>
                                                </svg>
                                            </span>
                                            <span>Empowering youth to rise above limitations and embrace their
                                                purpose.</span>
                                        </li>
                                        <li>
                                            <span class="pq-info-box-list-icon">
                                                <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle"
                                                    viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                                    </path>
                                                </svg>
                                            </span>
                                            <span>Connecting young people with real opportunities to learn and grow.</span>
                                        </li>
                                        <li>
                                            <span class="pq-info-box-list-icon">
                                                <svg aria-hidden="true" class="e-font-icon-svg e-fas-check-circle"
                                                    viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z">
                                                    </path>
                                                </svg>
                                            </span>
                                            <span>Inspiring creativity, innovation, and leadership across Africa.</span>
                                        </li>
                                    </ul>
                                </div>

                                <div class="pq-btn-container">
                                    <a href="https://bit.ly/InspiredVisionAfricaReg" class="pq-button pq-button-flat">
                                        <span>Register Now</span>
                                        <svg class="svg" height="100%" width="100%" viewBox="0 0 100 100"
                                            preserveAspectRatio="none">
                                            <path d="M0 0 H 100 V 100 H 00 Z" fill="transparent" stroke="black"
                                                vector-effect="non-scaling-stroke" stroke-dasharray="400"
                                                style="stroke-dashoffset: 96.6061px;"></path>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="pq-designer-page-1 pq-designer-aboutus-section">
        <div class="container">
            <div class="pq-designer-aboutus-section-wrapper">
                <div class="pq-section-title text-left">
                    <div class="pq-title">
                        <h5 class="pq-title-heading">UNLEASH
                            <span class="pq-title-last-word"> GREATNESS
                                <svg class="svg" height="100%" width="100%" viewBox="0 0 100 100"
                                    preserveAspectRatio="none">
                                    <path d="M0 0 H 100 V 100 H 0 Z" fill="transparent" stroke="black"
                                        vector-effect="non-scaling-stroke" stroke-dasharray="400"></path>
                                </svg>
                                <span class="pq-svg-dot"></span>
                            </span>
                        </h5>
                        <p class="pq-event-box-description">
                            The Inspire Vision Africa Youth Conference is designed to empower young people to rise above
                            limitations, embrace purpose, and unlock the greatness within. This first edition, themed
                            <strong>“Unleash Greatness: Empowering Africa’s Youth to Learn, Create, and Lead,”</strong>
                            will feature inspiring speakers, practical workshops, and opportunities to explore how
                            technology and social media can help youth grow as individuals and future leaders.
                        </p>

                    </div>
                </div>

                <div class="pq-event-wrapper pq-aboutus">
                    <div class="pq-event-list-1 pq-hover-active">
                        <div class="pq-event-box pq-style-1 pq-item-list">
                            <div class="pq-event-box-info">
                                <h5 class="pq-event-box-title">Empowerment Through Knowledge</h5>
                                <p class="pq-event-box-description">We provide tools, mentorship, and insights that equip
                                    young people with digital and leadership skills to succeed in a fast-evolving world.</p>
                            </div>
                        </div>
                        <div class="pq-event-box pq-style-1 pq-item-list">
                            <div class="pq-event-box-info">
                                <h5 class="pq-event-box-title">Innovation &amp; Creativity</h5>
                                <p class="pq-event-box-description">We encourage African youth to think differently, solve
                                    real problems, and use creativity as a force for positive change and opportunity.</p>
                            </div>
                        </div>
                        <div class="pq-event-box pq-style-1 pq-item-list">
                            <div class="pq-event-box-info">
                                <h5 class="pq-event-box-title">Leadership Development</h5>
                                <p class="pq-event-box-description">Through our programs and events, we help youth
                                    cultivate confidence, teamwork, and leadership skills that drive meaningful impact.</p>
                            </div>
                        </div>
                        <div class="pq-event-box pq-style-1 pq-item-list">
                            <div class="pq-event-box-info">
                                <h5 class="pq-event-box-title">Community &amp; Connection</h5>
                                <p class="pq-event-box-description">We foster collaboration and build strong networks
                                    among young Africans to share experiences, support one another, and create lasting
                                    change together.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="pq-carousel-brand pq-carousel-brand-page-1 ">
        <div class="container">
            <div class="row  ">
                <div class="pq-brand-title-div  text-center pq-top-border wow zoomIn">
                    <span class="pq-brand-title">OUR PARTNERS/SPONSORS</span>
                </div>
                <div class="col-lg-12 ">
                    <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="false" data-desk_num="5"
                        data-lap_num="4" data-tab_num="3" data-mob_num="1" data-mob_sm="1" data-autoplay="true"
                        data-loop="true" data-autowidth="false" data-margin="30">
                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="pq-brand-box">

                                      <img src="<?php echo e(asset('storage/' . $partner->image)); ?>" alt="partner"
                                        class="pq-client-img" style="width: 150px" >
                                    <svg class="svg" height="100%" width="100%" viewBox="0 0 100 100"
                                        preserveAspectRatio="none">
                                        <path d="M0 0 H 100 V 100 H 0 Z" fill="transparent" stroke="black"
                                            vector-effect="non-scaling-stroke" stroke-dasharray="400"></path>
                                    </svg>
                                    <span class="pq-svg-dot"></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\olawa\inspired-africa\resources\views/about.blade.php ENDPATH**/ ?>